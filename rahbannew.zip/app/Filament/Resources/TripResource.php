<?php
namespace App\Filament\Resources;

use App\Filament\Resources\TripResource\Pages;
use App\Filament\Resources\TripResource\RelationManagers;
use App\Models\Trip;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\BadgeColumn;

class TripResource extends Resource
{
    protected static ?string $model = Trip::class;
    protected static ?string $navigationIcon = 'heroicon-o-map-pin';
    protected static ?string $modelLabel = 'سفر';
    protected static ?string $pluralModelLabel = 'سفرها';

    public static function form(Form $form): Form
    {
        return $form->schema([
            Forms\Components\TextInput::make('user.name')->label('مسافر')->disabled(),
            Forms\Components\KeyValue::make('vehicle_info')->label('اطلاعات خودرو')->disabled(),
            Forms\Components\TextInput::make('status')->label('وضعیت')->disabled(),
            Forms\Components\DateTimePicker::make('created_at')->label('زمان شروع')->disabled(),
            Forms\Components\DateTimePicker::make('expires_at')->label('زمان انقضای لینک')->disabled(),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('user.name')->label('مسافر')->searchable(),
                BadgeColumn::make('status')->label('وضعیت')
                    ->colors([
                        'success' => 'completed',
                        'warning' => 'active',
                        'danger' => 'emergency',
                    ]),
                TextColumn::make('created_at')->label('زمان شروع')->dateTime('Y-m-d H:i')->sortable(),
                TextColumn::make('expires_at')->label('زمان انقضای لینک')->dateTime('Y-m-d H:i')->sortable(),
            ])
            ->filters([])
            ->actions([
                Tables\Actions\ViewAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }
    
    public static function getRelations(): array
    {
        // در مرحله بعد این بخش را تکمیل خواهیم کرد.
        return [        
            RelationManagers\GuardiansRelationManager::class,
            RelationManagers\LocationsRelationManager::class,
        ];
    }
    
    public static function getPages(): array
    {
        return [
            'index' => Pages\ListTrips::route('/'),
        ];
    }    
}