<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\TripController;

Route::post('/register', [AuthController::class, 'register']);
Route::post('/login', [AuthController::class, 'login']);

// مسیرهای محافظت شده که نیاز به توکن دارند
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);

    // Trip Management
    Route::post('/trips/start', [TripController::class, 'start']);
    Route::post('/trips/{trip}/location', [TripController::class, 'updateLocation']);
    Route::post('/trips/{trip}/complete', [TripController::class, 'complete']);
    Route::post('/trips/{trip}/sos', [TripController::class, 'triggerSOS']);
});